<?php


namespace App\Traits\AuthHelpers;


trait RemoteAPIServerCredentials
{
    private string $ABX_API_PARTNER = 'actionbet';
    private string $ABX_API_SECRETE_KEY = 'dlor0596ifksn2laoc94m596sk4n5ls';
    private string $ABX_API_ROOT='actionbet';
    private string $ABX_API_SKIN='actionbet';
    private string $ABX_API_PARENT = 'actionbetag';

    private string $ABX_API_BO_USERNAME='opactionbet';
    private string $ABX_API_BO_PASSWORD='554411Ff';
    private string $ABX_API_AGENT_USERNAME='telvida';
}
