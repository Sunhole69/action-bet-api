<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LiveGamesController extends Controller
{
    //
}
