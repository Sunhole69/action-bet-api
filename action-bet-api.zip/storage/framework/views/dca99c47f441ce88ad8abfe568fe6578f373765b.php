<?php $__env->startComponent('mail::message'); ?>
# hi, <?php echo e($user->firstname); ?> <br />

<p>You've done a good job? You have successfully reset your password, you'll need to login again with your new password.</p>

<?php $__env->startComponent('mail::button', ['url' => getenv('USER_FRONTEND_URL').'/sign-in']); ?>
    Login to your account
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Adurotimi Stephen\Documents\Telvida\Projects\action-bet-api\resources\views/emails/password-update.blade.php ENDPATH**/ ?>