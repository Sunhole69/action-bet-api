<?php $__env->startComponent('mail::message'); ?>
 # Hi <?php echo e($user->firstname); ?>


<p>We received a request to reset your password, please click the button bellow to reset it:</p>

<?php $__env->startComponent('mail::button', ['url' => getenv('USER_FRONTEND_URL').'/Auth/ResetPassword/'.$token]); ?>
    Reset your password
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Adurotimi Stephen\Documents\Telvida\Projects\action-bet-api\resources\views/emails/reset-password.blade.php ENDPATH**/ ?>