<?php $__env->startComponent('mail::message'); ?>
# Hi, <?php echo e($user->firstname); ?>

<p>Your Actionbet account was successfully created! 🎉🙏</p>
<p>Kindly verify your email address to ensure we have the working
    email, we need this to activate your account.</p>


<?php $__env->startComponent('mail::button', ['url' => getenv('USER_FRONTEND_URL').'/Auth/verify-email/'.$user->verification_token]); ?>
    Verify Email
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Adurotimi Stephen\Documents\Telvida\Projects\action-bet-api\resources\views/emails/welcome.blade.php ENDPATH**/ ?>