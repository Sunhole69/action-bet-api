<?php echo e($slot); ?>

<?php /**PATH C:\Users\Adurotimi Stephen\Documents\Telvida\Projects\action-bet-api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>